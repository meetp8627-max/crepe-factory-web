import { useState, useEffect } from "react";

/* ─────────────────────────────────────────────
   DATA
───────────────────────────────────────────── */
const NAV_LINKS = ["Home", "Menu", "About", "Gallery", "Contact"];

const SERVICES = [
  {
    emoji: "🥞",
    title: "Signature Crepes",
    desc: "Hand-crafted sweet & savoury French crêpes with fillings ranging from Nutella & banana to smoked chicken and béchamel — every bite is pure Paris.",
    tag: "Fan Favourite",
  },
  {
    emoji: "☕",
    title: "Artisan Café Drinks",
    desc: "Rich espresso pulls, silky cold brews, lavender lattes, and indulgent French-press mocktails — the perfect companion to your crêpe.",
    tag: "Open Late",
  },
  {
    emoji: "🍽️",
    title: "Continental Bites",
    desc: "From cheesy garlic bread and creamy mac-&-cheese pasta to golden waffles and decadent brownies — a full café menu that satisfies every craving.",
    tag: "Best Value",
  },
];

const TESTIMONIALS = [
  {
    name: "Priya S.",
    stars: 5,
    text: "Absolutely loved the aesthetic French vibe! The Nutella banana crêpe was out of this world. The staff was super warm and the whole place felt like a little Parisian escape right here in Vadodara. Will definitely be back!",
    date: "March 2024",
  },
  {
    name: "Rohan M.",
    stars: 5,
    text: "Best café experience in Vadodara, hands down. Came in at midnight and the place was buzzing. The mocktails were amazing and the prices are very student-friendly. Love that it's open until 3 AM!",
    date: "January 2024",
  },
];

/* ─────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────── */
function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <svg key={i} className="w-4 h-4 text-amber-400 fill-amber-400" viewBox="0 0 20 20">
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
        </svg>
      ))}
    </div>
  );
}

/* ─────────────────────────────────────────────
   COMPONENTS
───────────────────────────────────────────── */

/* --- Header / Nav --- */
function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-[#1a0a00]/95 backdrop-blur-md shadow-lg shadow-black/30" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <button
            onClick={() => scrollTo("home")}
            className="flex items-center gap-2.5 group focus:outline-none"
          >
            <span className="text-3xl leading-none">🥞</span>
            <div className="leading-tight">
              <div className="font-['Playfair_Display'] text-lg font-bold text-amber-300 tracking-wide group-hover:text-amber-200 transition-colors">
                Crepe Factory
              </div>
              <div className="text-[10px] font-['Lato'] text-amber-400/70 tracking-[0.2em] uppercase">
                French Café · Vadodara
              </div>
            </div>
          </button>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-7">
            {NAV_LINKS.map((link) => (
              <button
                key={link}
                onClick={() => scrollTo(link.toLowerCase())}
                className="font-['Lato'] text-sm text-amber-100/80 hover:text-amber-300 transition-colors tracking-wide uppercase font-medium focus:outline-none"
              >
                {link}
              </button>
            ))}
          </nav>

          {/* Call Now CTA */}
          <a
            href="tel:+917383221183"
            className="hidden md:inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-[#1a0a00] font-['Lato'] font-bold text-sm px-5 py-2.5 rounded-full transition-all duration-200 hover:shadow-lg hover:shadow-amber-400/30 hover:-translate-y-0.5"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
            </svg>
            Call Now
          </a>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden text-amber-300 focus:outline-none p-2"
            onClick={() => setMenuOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {menuOpen ? (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            ) : (
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden overflow-hidden transition-all duration-300 ${
            menuOpen ? "max-h-96 pb-4" : "max-h-0"
          }`}
        >
          <div className="bg-[#1a0a00]/95 backdrop-blur-md rounded-2xl mt-2 p-4 flex flex-col gap-3">
            {NAV_LINKS.map((link) => (
              <button
                key={link}
                onClick={() => scrollTo(link.toLowerCase())}
                className="text-left font-['Lato'] text-sm text-amber-100/80 hover:text-amber-300 transition-colors py-2 px-3 rounded-lg hover:bg-amber-500/10 uppercase tracking-wider font-medium"
              >
                {link}
              </button>
            ))}
            <a
              href="tel:+917383221183"
              className="flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-400 text-[#1a0a00] font-bold text-sm px-5 py-3 rounded-full transition-all"
            >
              📞 Call Now – +91 73832 21183
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}

/* --- Hero Section --- */
function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        background:
          "linear-gradient(135deg, #1a0a00 0%, #2d1200 30%, #3d1a00 60%, #1a0a00 100%)",
      }}
    >
      {/* Decorative blobs */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-amber-700/5 rounded-full blur-3xl pointer-events-none" />

      {/* French pattern overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg, #d97706 0, #d97706 1px, transparent 0, transparent 50%)",
          backgroundSize: "30px 30px",
        }}
      />

      {/* Fleur-de-lis decorations */}
      <div className="absolute top-24 left-8 text-amber-600/20 text-6xl pointer-events-none select-none hidden lg:block">
        ⚜
      </div>
      <div className="absolute top-32 right-8 text-amber-600/20 text-5xl pointer-events-none select-none hidden lg:block">
        ⚜
      </div>
      <div className="absolute bottom-32 left-16 text-amber-600/15 text-4xl pointer-events-none select-none hidden lg:block">
        ⚜
      </div>
      <div className="absolute bottom-24 right-16 text-amber-600/15 text-7xl pointer-events-none select-none hidden lg:block">
        ⚜
      </div>

      <div className="relative z-10 text-center max-w-5xl mx-auto px-4 py-24">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-['Lato'] font-bold tracking-[0.2em] uppercase px-5 py-2 rounded-full mb-8 backdrop-blur-sm">
          <span>⭐</span>
          <span>4.9 Google Rated · Viral French Café · Vadodara</span>
          <span>⭐</span>
        </div>

        {/* Main Headline */}
        <h1 className="font-['Playfair_Display'] text-5xl sm:text-6xl md:text-7xl lg:text-8xl text-white leading-[1.05] mb-6">
          <span className="block">Vadodara's Most</span>
          <span className="block text-amber-400 italic">Loved French Café</span>
        </h1>

        {/* Sub-headline */}
        <p className="font-['Lato'] text-lg sm:text-xl text-amber-100/70 max-w-2xl mx-auto mb-10 leading-relaxed">
          Hand-crafted crêpes, artisan coffees & continental bites in a stunning aesthetic space.
          Open until <span className="text-amber-300 font-bold">3 AM</span> — because good food has no curfew.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="tel:+917383221183"
            className="group inline-flex items-center gap-3 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-[#1a0a00] font-['Lato'] font-bold text-base px-8 py-4 rounded-full transition-all duration-200 hover:shadow-xl hover:shadow-amber-500/40 hover:-translate-y-1 w-full sm:w-auto justify-center"
          >
            <svg className="w-5 h-5 group-hover:rotate-12 transition-transform" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
            </svg>
            Get a Free Quote
          </a>
          <a
            href="https://maps.app.goo.gl/v8Cuewspi4LGKrSc8"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 border-2 border-amber-500/50 hover:border-amber-400 text-amber-300 hover:text-amber-200 font-['Lato'] font-bold text-base px-8 py-4 rounded-full transition-all duration-200 hover:bg-amber-500/10 hover:-translate-y-1 w-full sm:w-auto justify-center backdrop-blur-sm"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
            </svg>
            Find Us on Maps
          </a>
        </div>

        {/* Quick stats */}
        <div className="mt-16 grid grid-cols-3 gap-6 max-w-md mx-auto">
          {[
            { num: "4.9⭐", label: "Google Rating" },
            { num: "3 AM", label: "Open Late" },
            { num: "₹700", label: "For Two" },
          ].map(({ num, label }) => (
            <div key={label} className="text-center">
              <div className="font-['Playfair_Display'] text-xl sm:text-2xl font-bold text-amber-400">
                {num}
              </div>
              <div className="font-['Lato'] text-xs text-amber-100/50 mt-0.5 uppercase tracking-wider">
                {label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="font-['Lato'] text-xs text-amber-100/40 tracking-widest uppercase">Scroll</span>
        <svg className="w-4 h-4 text-amber-400/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </section>
  );
}

/* --- Services Section --- */
function Services() {
  return (
    <section
      id="menu"
      className="py-24 px-4 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #0f0600 0%, #1a0a00 100%)" }}
    >
      {/* Divider top */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-600/30 to-transparent" />

      <div className="max-w-7xl mx-auto">
        {/* Heading */}
        <div className="text-center mb-16">
          <span className="inline-block font-['Lato'] text-xs text-amber-500 tracking-[0.3em] uppercase font-bold mb-4">
            What We Serve
          </span>
          <h2 className="font-['Playfair_Display'] text-4xl sm:text-5xl text-white mb-5">
            A Taste of <span className="text-amber-400 italic">Paris</span> in Vadodara
          </h2>
          <p className="font-['Lato'] text-amber-100/60 max-w-xl mx-auto text-base leading-relaxed">
            Every dish at Crepe Factory is crafted with love, fresh ingredients, and a true French spirit.
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
          {SERVICES.map(({ emoji, title, desc, tag }) => (
            <div
              key={title}
              className="group relative bg-gradient-to-b from-[#2a1200] to-[#1a0a00] border border-amber-800/30 rounded-2xl p-8 hover:border-amber-500/50 hover:-translate-y-2 transition-all duration-300 hover:shadow-2xl hover:shadow-amber-900/40 cursor-default overflow-hidden"
            >
              {/* Hover glow */}
              <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                style={{ background: "radial-gradient(circle at 50% 0%, rgba(245,158,11,0.08) 0%, transparent 70%)" }}
              />

              {/* Tag */}
              <div className="absolute top-5 right-5">
                <span className="bg-amber-500/15 border border-amber-500/30 text-amber-400 text-[10px] font-['Lato'] font-bold tracking-wider uppercase px-2.5 py-1 rounded-full">
                  {tag}
                </span>
              </div>

              {/* Emoji */}
              <div className="text-5xl mb-5 group-hover:scale-110 transition-transform duration-300 inline-block">
                {emoji}
              </div>

              {/* Content */}
              <h3 className="font-['Playfair_Display'] text-xl text-white mb-3">{title}</h3>
              <p className="font-['Lato'] text-amber-100/60 text-sm leading-relaxed">{desc}</p>

              {/* CTA link */}
              <div className="mt-6">
                <a
                  href="tel:+917383221183"
                  className="inline-flex items-center gap-2 text-amber-400 hover:text-amber-300 font-['Lato'] font-bold text-sm transition-colors group/link"
                >
                  <span>Order Now</span>
                  <svg className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-14">
          <a
            href="tel:+917383221183"
            className="inline-flex items-center gap-3 bg-transparent border-2 border-amber-500/60 hover:bg-amber-500 hover:border-amber-500 text-amber-400 hover:text-[#1a0a00] font-['Lato'] font-bold text-sm px-8 py-3.5 rounded-full transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/30"
          >
            View Full Menu – Call Us
          </a>
        </div>
      </div>

      {/* Divider bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-600/30 to-transparent" />
    </section>
  );
}

/* --- Gallery Strip --- */
function Gallery() {
  const photos = [
    { emoji: "🥞", label: "Signature Crêpes", bg: "from-amber-900/60 to-amber-800/40" },
    { emoji: "🧇", label: "Belgian Waffles", bg: "from-yellow-900/60 to-amber-800/40" },
    { emoji: "☕", label: "Artisan Coffee", bg: "from-stone-800/60 to-amber-900/40" },
    { emoji: "🍫", label: "Chocolate Brownie", bg: "from-amber-950/60 to-stone-800/40" },
    { emoji: "🥗", label: "Mac & Cheese Pasta", bg: "from-yellow-950/60 to-amber-900/40" },
    { emoji: "🥤", label: "Signature Mocktails", bg: "from-amber-900/60 to-stone-800/40" },
  ];

  return (
    <section
      id="gallery"
      className="py-24 px-4"
      style={{ background: "#0f0600" }}
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <span className="inline-block font-['Lato'] text-xs text-amber-500 tracking-[0.3em] uppercase font-bold mb-4">
            Our Menu
          </span>
          <h2 className="font-['Playfair_Display'] text-4xl sm:text-5xl text-white mb-4">
            Made Fresh, <span className="text-amber-400 italic">Every Day</span>
          </h2>
          <p className="font-['Lato'] text-amber-100/50 text-sm">Come hungry. Leave obsessed.</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {photos.map(({ emoji, label, bg }) => (
            <div
              key={label}
              className={`group relative rounded-2xl overflow-hidden bg-gradient-to-br ${bg} border border-amber-800/20 aspect-[4/3] flex flex-col items-center justify-center hover:border-amber-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-900/30 cursor-default`}
            >
              <div className="text-5xl sm:text-6xl mb-3 group-hover:scale-110 transition-transform duration-300">
                {emoji}
              </div>
              <span className="font-['Lato'] text-xs sm:text-sm text-amber-200/70 font-medium tracking-wide text-center px-2">
                {label}
              </span>
              <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl pointer-events-none" />
            </div>
          ))}
        </div>

        <p className="text-center mt-8 font-['Lato'] text-xs text-amber-100/30 tracking-wider">
          📍 Visit us to experience the full menu in person
        </p>
      </div>
    </section>
  );
}

/* --- About + Testimonials --- */
function About() {
  return (
    <section
      id="about"
      className="py-24 px-4 relative overflow-hidden"
      style={{ background: "linear-gradient(180deg, #0f0600 0%, #1a0a00 100%)" }}
    >
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-600/30 to-transparent" />

      <div className="max-w-7xl mx-auto">
        {/* About Story */}
        <div className="grid lg:grid-cols-2 gap-14 items-center mb-24">
          {/* Left – decorative card */}
          <div className="relative">
            <div className="relative bg-gradient-to-br from-[#2a1200] to-[#1a0900] border border-amber-800/30 rounded-3xl p-8 sm:p-10 overflow-hidden">
              {/* Background pattern */}
              <div
                className="absolute inset-0 opacity-5"
                style={{
                  backgroundImage:
                    "radial-gradient(circle, #d97706 1px, transparent 1px)",
                  backgroundSize: "24px 24px",
                }}
              />
              <div className="relative z-10">
                <div className="text-7xl mb-6">⚜️</div>
                <div className="font-['Playfair_Display'] text-3xl italic text-amber-300 leading-snug mb-4">
                  "Food. Fun.<br />Aesthetic Vibes & More."
                </div>
                <div className="font-['Lato'] text-amber-100/50 text-sm leading-relaxed mb-6">
                  — Crepe Factory motto
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: "📍", label: "Waghodia, Vadodara" },
                    { icon: "⏰", label: "Open until 3 AM" },
                    { icon: "⭐", label: "4.9 Google Rating" },
                    { icon: "💰", label: "₹700 for two" },
                  ].map(({ icon, label }) => (
                    <div key={label} className="flex items-center gap-2.5">
                      <span className="text-lg">{icon}</span>
                      <span className="font-['Lato'] text-xs text-amber-100/60">{label}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -top-4 -right-4 bg-amber-500 text-[#1a0a00] font-['Lato'] font-bold text-xs px-4 py-2 rounded-full shadow-lg shadow-amber-500/30 rotate-3">
              🏆 #1 French Café in Vadodara
            </div>
          </div>

          {/* Right – text */}
          <div>
            <span className="inline-block font-['Lato'] text-xs text-amber-500 tracking-[0.3em] uppercase font-bold mb-4">
              Our Story
            </span>
            <h2 className="font-['Playfair_Display'] text-4xl sm:text-5xl text-white mb-6 leading-tight">
              Vadodara's Own<br />
              <span className="text-amber-400 italic">Slice of France</span>
            </h2>
            <div className="font-['Lato'] text-amber-100/65 text-base leading-8 space-y-4">
              <p>
                Nestled in Waghodia, Vadodara, <strong className="text-amber-300">Crepe Factory</strong> was born from a dream — to bring the charm of authentic French crêpe culture to the heart of Gujarat.
              </p>
              <p>
                What started as a cosy café with a handful of signature crêpes has grown into Vadodara's most-loved French dining experience, rated <strong className="text-amber-300">4.9 stars</strong> on Google by hundreds of happy customers.
              </p>
              <p>
                Our unicorn-themed interiors, peaceful vibe, and impeccably crafted menu make us the perfect spot — whether it's a midnight craving, a student hangout, or a date night. We're open until <strong className="text-amber-300">3 AM</strong> because great food deserves no limits.
              </p>
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              {["Multicuisine", "Continental", "French Crêpes", "Late Night", "Aesthetic Vibe"].map((tag) => (
                <span
                  key={tag}
                  className="bg-amber-500/10 border border-amber-500/25 text-amber-400 font-['Lato'] text-xs font-bold px-3.5 py-1.5 rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>

            <div className="mt-8">
              <a
                href="tel:+917383221183"
                className="inline-flex items-center gap-3 bg-amber-500 hover:bg-amber-400 text-[#1a0a00] font-['Lato'] font-bold text-sm px-7 py-3.5 rounded-full transition-all duration-200 hover:shadow-lg hover:shadow-amber-500/30 hover:-translate-y-0.5"
              >
                📞 Reserve Your Table
              </a>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="text-center mb-12">
          <span className="inline-block font-['Lato'] text-xs text-amber-500 tracking-[0.3em] uppercase font-bold mb-4">
            Happy Customers
          </span>
          <h2 className="font-['Playfair_Display'] text-3xl sm:text-4xl text-white">
            What People Are <span className="text-amber-400 italic">Saying</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {TESTIMONIALS.map(({ name, stars, text, date }) => (
            <div
              key={name}
              className="group bg-gradient-to-b from-[#2a1200] to-[#1a0a00] border border-amber-800/30 rounded-2xl p-8 hover:border-amber-500/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-amber-900/30 relative overflow-hidden"
            >
              {/* Quote mark */}
              <div className="absolute top-4 right-6 text-7xl text-amber-800/20 font-['Playfair_Display'] leading-none select-none pointer-events-none">
                "
              </div>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-500/30 flex items-center justify-center font-['Playfair_Display'] font-bold text-amber-400 text-lg">
                  {name[0]}
                </div>
                <div>
                  <div className="font-['Lato'] font-bold text-white text-sm">{name}</div>
                  <div className="font-['Lato'] text-amber-100/40 text-xs">{date}</div>
                </div>
                <div className="ml-auto">
                  <StarRating count={stars} />
                </div>
              </div>

              <p className="font-['Lato'] text-amber-100/70 text-sm leading-relaxed relative z-10">
                "{text}"
              </p>

              <div className="mt-4 flex items-center gap-1.5">
                <span className="text-xs font-['Lato'] text-amber-500/60">via Google Reviews</span>
                <svg className="w-3 h-3 text-amber-500/60" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-600/30 to-transparent" />
    </section>
  );
}

/* --- Contact / Footer --- */
function Footer() {
  return (
    <footer
      id="contact"
      className="py-20 px-4 relative"
      style={{ background: "linear-gradient(180deg, #1a0a00 0%, #0a0400 100%)" }}
    >
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-600/30 to-transparent" />

      <div className="max-w-7xl mx-auto">
        {/* Top heading */}
        <div className="text-center mb-14">
          <span className="inline-block font-['Lato'] text-xs text-amber-500 tracking-[0.3em] uppercase font-bold mb-4">
            Visit Us
          </span>
          <h2 className="font-['Playfair_Display'] text-4xl sm:text-5xl text-white mb-4">
            Come Find <span className="text-amber-400 italic">Us</span>
          </h2>
          <p className="font-['Lato'] text-amber-100/50 text-sm max-w-md mx-auto">
            We're open late so you can visit whenever the craving strikes!
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-14">
          {/* Map */}
          <div className="lg:col-span-2 rounded-2xl overflow-hidden border border-amber-800/30 hover:border-amber-500/40 transition-colors duration-300 h-64 sm:h-80">
            <iframe
              title="Crepe Factory Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3697.3!2d73.3262!3d22.2923!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395fc5e0c39a4b1d%3A0x1234567890abcdef!2sCrepe%20Factory!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
              width="100%"
              height="100%"
              style={{ border: 0, filter: "invert(90%) hue-rotate(180deg) saturate(0.8)" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          {/* Info */}
          <div className="flex flex-col gap-6">
            {/* Address */}
            <div className="bg-gradient-to-b from-[#2a1200] to-[#1a0a00] border border-amber-800/30 rounded-2xl p-6 hover:border-amber-500/30 transition-colors">
              <h3 className="font-['Playfair_Display'] text-lg text-amber-400 mb-3 flex items-center gap-2">
                <span>📍</span> Address
              </h3>
              <p className="font-['Lato'] text-amber-100/65 text-sm leading-relaxed">
                17/B, Gurukrupa Avenue,<br />
                Near Heritage Girls Hostel,<br />
                Opp. Sumandeep Vidhyapeeth,<br />
                Waghodia, Vadodara – 391760
              </p>
              <a
                href="https://maps.app.goo.gl/v8Cuewspi4LGKrSc8"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 mt-3 text-xs text-amber-500 hover:text-amber-400 font-['Lato'] font-bold transition-colors"
              >
                Get Directions →
              </a>
            </div>

            {/* Phone */}
            <div className="bg-gradient-to-b from-[#2a1200] to-[#1a0a00] border border-amber-800/30 rounded-2xl p-6 hover:border-amber-500/30 transition-colors">
              <h3 className="font-['Playfair_Display'] text-lg text-amber-400 mb-3 flex items-center gap-2">
                <span>📞</span> Phone
              </h3>
              <a
                href="tel:+917383221183"
                className="font-['Lato'] font-bold text-white text-lg hover:text-amber-300 transition-colors"
              >
                +91 73832 21183
              </a>
              <p className="font-['Lato'] text-amber-100/40 text-xs mt-1">
                Tap to call directly
              </p>
            </div>

            {/* Hours */}
            <div className="bg-gradient-to-b from-[#2a1200] to-[#1a0a00] border border-amber-800/30 rounded-2xl p-6 hover:border-amber-500/30 transition-colors">
              <h3 className="font-['Playfair_Display'] text-lg text-amber-400 mb-3 flex items-center gap-2">
                <span>⏰</span> Hours
              </h3>
              <div className="space-y-1.5">
                <div className="flex justify-between font-['Lato'] text-sm">
                  <span className="text-amber-100/60">Mon – Fri</span>
                  <span className="text-white font-medium">11 AM – 3 AM</span>
                </div>
                <div className="flex justify-between font-['Lato'] text-sm">
                  <span className="text-amber-100/60">Sat – Sun</span>
                  <span className="text-amber-400 font-bold">11 AM – 3 AM</span>
                </div>
              </div>
              <div className="mt-3 inline-flex items-center gap-1.5 bg-green-500/15 border border-green-500/30 text-green-400 text-[10px] font-bold px-2.5 py-1 rounded-full font-['Lato']">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                Open Late Every Day
              </div>
            </div>
          </div>
        </div>

        {/* Social + CTA row */}
        <div className="border-t border-amber-800/20 pt-10 flex flex-col sm:flex-row items-center justify-between gap-6">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <span className="text-2xl">🥞</span>
            <div>
              <div className="font-['Playfair_Display'] text-base font-bold text-amber-300">
                Crepe Factory
              </div>
              <div className="font-['Lato'] text-[10px] text-amber-100/40 tracking-widest uppercase">
                French Café · Vadodara
              </div>
            </div>
          </div>

          {/* Social links */}
          <div className="flex items-center gap-3">
            <span className="font-['Lato'] text-xs text-amber-100/40 mr-1">Follow us:</span>
            {/* Instagram */}
            <a
              href="https://www.instagram.com/crepefactory.co/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 bg-amber-500/10 border border-amber-500/25 rounded-full flex items-center justify-center text-amber-400 hover:bg-amber-500 hover:text-[#1a0a00] hover:border-amber-500 transition-all duration-200 hover:-translate-y-0.5"
              aria-label="Instagram"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
              </svg>
            </a>
            {/* Google Maps */}
            <a
              href="https://maps.app.goo.gl/v8Cuewspi4LGKrSc8"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 bg-amber-500/10 border border-amber-500/25 rounded-full flex items-center justify-center text-amber-400 hover:bg-amber-500 hover:text-[#1a0a00] hover:border-amber-500 transition-all duration-200 hover:-translate-y-0.5"
              aria-label="Google Maps"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
              </svg>
            </a>
            {/* WhatsApp */}
            <a
              href="https://wa.me/917383221183"
              target="_blank"
              rel="noopener noreferrer"
              className="w-9 h-9 bg-amber-500/10 border border-amber-500/25 rounded-full flex items-center justify-center text-amber-400 hover:bg-amber-500 hover:text-[#1a0a00] hover:border-amber-500 transition-all duration-200 hover:-translate-y-0.5"
              aria-label="WhatsApp"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            </a>
          </div>

          {/* Call CTA */}
          <a
            href="tel:+917383221183"
            className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-400 text-[#1a0a00] font-['Lato'] font-bold text-sm px-6 py-3 rounded-full transition-all duration-200 hover:shadow-lg hover:shadow-amber-500/30 hover:-translate-y-0.5"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
            </svg>
            Call Now
          </a>
        </div>

        {/* Copyright */}
        <div className="mt-8 text-center">
          <p className="font-['Lato'] text-xs text-amber-100/25">
            © {new Date().getFullYear()} Crepe Factory French Café, Vadodara. All rights reserved. 🥞
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ─────────────────────────────────────────────
   FLOATING CALL BUTTON (Mobile)
───────────────────────────────────────────── */
function FloatingCTA() {
  return (
    <a
      href="tel:+917383221183"
      className="fixed bottom-6 right-6 z-50 md:hidden flex items-center gap-2.5 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-[#1a0a00] font-['Lato'] font-bold text-sm px-5 py-3.5 rounded-full shadow-xl shadow-amber-900/50 transition-all duration-200 hover:-translate-y-0.5"
      aria-label="Call Now"
    >
      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
        <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z" />
      </svg>
      Call Now
    </a>
  );
}

/* ─────────────────────────────────────────────
   APP
───────────────────────────────────────────── */
export default function App() {
  return (
    <div className="min-h-screen" style={{ fontFamily: "'Lato', sans-serif" }}>
      <Header />
      <main>
        <Hero />
        <Services />
        <Gallery />
        <About />
      </main>
      <Footer />
      <FloatingCTA />
    </div>
  );
}
